package com.iflytek.isvdemo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Toast;

/**
 * 用户名输入页面
 *
 * @author iFlytek &nbsp;&nbsp;&nbsp;<a href="http://http://www.xfyun.cn/">讯飞语音云</a>
 */
public class LoginActivity extends Activity implements OnClickListener{
	private Toast mToast;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_login);
		requestPermissions();
		findViewById(R.id.btn_confirm).setOnClickListener(LoginActivity.this);
		mToast = Toast.makeText(LoginActivity.this, "", Toast.LENGTH_SHORT);
	}
	
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_confirm:
			// 过滤掉不合法的用户名
			String uname = ((EditText) findViewById(R.id.edt_uname)).getText().toString();
			if (TextUtils.isEmpty(uname)) {
				showTip("用户名不能为空");
				return;
			} else {
				Pattern p = Pattern.compile("[\u4e00-\u9fa5]");
				Matcher m = p.matcher(uname);
				if (m.find()) {
					showTip("不支持中文字符");
					return;
				} else if (uname.contains(" ")) {
					showTip("不能包含空格");
					return;
				} else if (!uname.matches("^[a-zA-Z][a-zA-Z0-9_]{5,17}")) {
					showTip("6-18个字母、数字或下划线的组合，以字母开头");
					return;
				} 
			}
			
			Intent intent = new Intent(LoginActivity.this, IsvDemo.class);
			intent.putExtra("uname", uname);
			startActivity(intent);
			break;
			
		default:
			break;
		}
	}	
	
	private void showTip(final String str) {
		mToast.setText(str);
		mToast.show();
	}

	private void requestPermissions(){
		try {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
				int permission = ActivityCompat.checkSelfPermission(this,
						Manifest.permission.WRITE_EXTERNAL_STORAGE);
				if(permission!= PackageManager.PERMISSION_GRANTED) {
					ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE,
							Manifest.permission.LOCATION_HARDWARE,Manifest.permission.READ_PHONE_STATE,
							Manifest.permission.WRITE_SETTINGS,Manifest.permission.READ_EXTERNAL_STORAGE,
							Manifest.permission.RECORD_AUDIO,Manifest.permission.READ_CONTACTS},0x0010);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
	}
	
}
